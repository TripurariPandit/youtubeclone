import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    displayName: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')).displayName : '',
    email: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')).email : '',
    photoURL: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')).photoURL : '',
}

const userInfoSlice = createSlice({
    name: 'userInfo',
    initialState,
    reducers: {
        setUserInfo: (state, action)=>{
            state.userInfo = action.payload;
        }
    }
});

export const userInfoReducer = userInfoSlice.reducer;

export const userInfoAction = userInfoSlice.actions;