import { createSlice } from "@reduxjs/toolkit";
import { isLoggedIn } from "../../utilsData/constants";
const initialState = {
  isLoggedIn: localStorage.getItem(isLoggedIn) === "true",
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    loginRequest: (state, action) => {
      state.isLoggedIn = false;
    },

    loginSuccess: (state, action) => {
      localStorage.setItem(isLoggedIn, true);
      localStorage.setItem("user", JSON.stringify(action.payload));
      state.isLoggedIn = true;
    },

    loginFailure: (state, action) => {
      localStorage.removeItem(isLoggedIn);
      localStorage.removeItem("user");
      state.isLoggedIn = false;
      state.error = action.payload;
    },
  },
});

export const authReducer = authSlice.reducer;

export const authAction = authSlice.actions;
