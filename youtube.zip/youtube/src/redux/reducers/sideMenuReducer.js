import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    toggle: false,
    isFixed: false
};

const sideMenuSlice = createSlice({
    name: 'sideMenu',
    initialState,
    reducers: {
        toggleSideMenu: (state, action)=>{
            state.toggle = !state.toggle;
        },

        isFixedSideMenu: (state, action)=>{
            state.toggle = action.payload.toggle;
            state.isFixed = action.payload.isFixed;
        }
    }
});

export const sideMenuReducer = sideMenuSlice.reducer;

export const sideMenuAction = sideMenuSlice.actions;