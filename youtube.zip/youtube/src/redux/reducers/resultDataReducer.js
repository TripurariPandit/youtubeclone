import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  data: {
    videos: [],
    video: new Map(),
    channel: {},
    comments: [],
  },
};

const resultDataSlice = createSlice({
    name: 'resultData',
    initialState,
    reducers: {
        setVideosSuccess: (state, action) => {
            state.data.videos = action.payload.videos;
        },
        setVideo: (state, action) => {
            const { videoId, videoData } = action.payload;
            state.data.video.set(videoId, videoData);
        },
        setVideoComments: (state, action) => {
            state.data.comments = action.payload.comments;
        },
        setChannel: (state, action) => {
            const { channelId, channelData } = action.payload;
            state.data.channel[channelId] = channelData;
        },
        setVideosLoading: (state, action) => {
            state.loading = action.payload;
        },
        setVideosError: (state, action) => {
            state.error = action.payload;
        }
    }
});

export const resultDataReducer = resultDataSlice.reducer;

export const resultDataAction = resultDataSlice.actions;