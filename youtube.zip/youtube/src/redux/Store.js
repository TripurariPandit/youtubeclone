import { configureStore } from "@reduxjs/toolkit";
import { enableMapSet } from 'immer'; // Import enableMapSet from Immer

import { authReducer } from "./reducers/authReducer";
import { userInfoReducer } from "./reducers/userInfoReducer";
import { sideMenuReducer } from "./reducers/sideMenuReducer";
import { resultDataReducer } from "./reducers/resultDataReducer";
// Enable the Map and Set support in Immer
enableMapSet();

export const store = configureStore({
  reducer: {
    userInfo: userInfoReducer,
    auth: authReducer,
    sideMenu: sideMenuReducer,
    resultData: resultDataReducer,
  },
});
