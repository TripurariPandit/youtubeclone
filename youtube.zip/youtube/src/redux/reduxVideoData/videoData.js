import YT_API from "../../api/api";
import { resultDataAction } from "../reducers/resultDataReducer";

export const setVideos = (videos = false, count = 5) => {
  return async (dispatch) => {
    try {
      const response = await YT_API.get("search", {
        params: {
          part: "snippet",
          maxResults: count,
          q: videos ? videos : "",
          type: "video",
          videoDuration: "medium",
        },
      });
      dispatch(
        resultDataAction.setVideosSuccess({ videos: response.data.items })
      );
    } catch (error) {
      console.log(error);
    }
  };
};

export const setVideo = (videoId) => {
  return async (dispatch) => {
    try {
      const response = await YT_API.get("videos", {
        params: {
          part: "statistics,snippet",
          id: videoId,
        },
      });
      dispatch(resultDataAction.setVideo({videoId, videoData: response.data.items[0] }));
    } catch (error) {
      console.log(error);
    }
  };
};

export const setVideoComments = (videoId, count = 10) => {
  return async (dispatch) => {
    try {
      const response = await YT_API.get("commentThreads", {
        params: {
          part: "snippet",
          videoId: videoId,
          maxResults: count,
        },
      });
      dispatch(
        resultDataAction.setVideoComments({ comments: response.data.items })
      );
    } catch (error) {
      console.log(error);
    }
  };
};

export const setChannel = (channelId) => {
  return async (dispatch) => {
    try {
      const response = await YT_API.get("channels", {
        params: {
          part: "snippet,statistics",
          id: channelId,
        },
      });
      dispatch(
        resultDataAction.setChannel({
          channelId,
          channelData: response.data.items[0],
        })
      );
    } catch (error) {
      console.log(error);
    }
  };
};
