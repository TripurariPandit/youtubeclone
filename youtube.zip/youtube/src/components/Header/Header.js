import { IconButton } from "@mui/material";
import { useEffect, useState } from "react";
import MenuIcon from "@mui/icons-material/Menu";
import "./Header.scss";
import { useDispatch, useSelector } from "react-redux";
import createIcon from "../../assets/icons/createIcon.png";
import notificationIcon from "../../assets/icons/notificationIcon.png";
import { StyledIcon, StyledIconButton } from "../../styles/styled";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import { Link, useNavigate } from "react-router-dom";
import logo from "../../assets/images/YT-white.png";
import miniLogo from "../../assets/images/YT_mini.png";
import { sideMenuAction } from "../../redux/reducers/sideMenuReducer";

const Header = () => {
  const dispatch = useDispatch();
  const userInfo = useSelector((state) => state.userInfo);
  const navigate = useNavigate();
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);

  const { photoURL } = userInfo;

  const handleChangeToggle = () => {
    dispatch(sideMenuAction.toggleSideMenu());
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    let searchTxt = e.target.elements[0].value.trim().replaceAll(/\s+/g, "+");
    navigate("/search/" + searchTxt);
  };

  useEffect(() => {
    const handleResize = () => {
      setScreenWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <header id="header" className="header">
      <nav className="header-nav">
        <div className="header-nav-wrapper">
          <div className="header__left">
            <IconButton
              aria-label="Youtube Logo"
              size="medium"
              onClick={handleChangeToggle}
            >
              <MenuIcon fontSize="inherit" />
            </IconButton>
            <Link to={"/"}>
              <img
                src={`${screenWidth > 650 ? logo : miniLogo}`}
                className={`${screenWidth < 650 ? "header-miniLogo" : ""}`}
                alt=""
              />
            </Link>
          </div>

          <div className="header__center">
            <form className="header__search-form" onSubmit={handleSearchSubmit}>
              <input
                className="header__search-form__input"
                type="text"
                placeholder="Search"
              />
              <button className="header__search-form__button" type="submit">
                <SearchRoundedIcon />
              </button>
            </form>
          </div>

          <div className="header__right">
            <IconButton aria-label="upload new video" size="large">
              <StyledIconButton width="23px" height="23px">
                <StyledIcon
                  className="header__icon__content"
                  src={createIcon}
                  alt="Create"
                  height="16px"
                  width="22px"
                ></StyledIcon>
              </StyledIconButton>
            </IconButton>
            <IconButton aria-label="Notification Button" size="large">
              <StyledIconButton width="23px" height="23px">
                <StyledIcon
                  className="header__icon__content"
                  src={notificationIcon}
                  alt="Create"
                  width="19px"
                  height="23px"
                ></StyledIcon>
              </StyledIconButton>
            </IconButton>
            <IconButton aria-label="user settings button" size="medium">
              <img className="header__user-img" src={photoURL} alt="" />
            </IconButton>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
