import "./SideMenu.scss";
import ExpandMoreOutlinedIcon from "@mui/icons-material/ExpandMoreOutlined";
import { Link } from "react-router-dom";
import { sideBarData } from "../../utilsData/sideBarData";
import { useSelector } from "react-redux";

const SideMenu = () => {
  const { toggle } = useSelector((state) => state.sideMenu);
  return (
    <div className="side-menu">
      <div className="side-menu__items">
        {sideBarData.main.map((item) => (
          <Link to={item.link} key={item.id} className='item-link'>
            <div className="side-menu__items__item">
              <item.icon></item.icon>
              {toggle ? <span>{item.text}</span> : null}
            </div>
          </Link>
        ))}
      </div>

      {toggle && (
        <div className="side-menu__items">
          {sideBarData.secondary.map((item) => (
            <Link to={item.link} key={item.id} className='item-link'>
              <div className="side-menu__items__item">
                <item.icon></item.icon>
                <span>{item.text}</span>
              </div>
            </Link>
          ))}

          <div className="side-menu__items__item">
            <ExpandMoreOutlinedIcon></ExpandMoreOutlinedIcon>
            <span>Show more</span>
          </div>
        </div>
      )}

      {toggle && (
        <div className="side-menu__items">
          {sideBarData.setting.map((item) => (
            <div className="side-menu__items__item" key={item.id}>
              <item.icon></item.icon>
              <span>{item.text}</span>
            </div>
          ))}
        </div>
      )}
      {toggle && (
        <div className="side-menu__items">
          {sideBarData.setting.map((item) => (
            <div className="side-menu__items__item" key={item.id}>
              <item.icon></item.icon>
              <span>{item.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SideMenu;
