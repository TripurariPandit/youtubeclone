import { useState } from "react";
import AllComments from "./AllComments";
import { Button, FormControl, Input } from "@mui/material";
import { useSelector } from "react-redux";

const Comment = () => {
  const [isFocused, setIsFocused] = useState(false);
  const resultData = useSelector((state) => state.resultData);
  const userInfo = useSelector((state) => state.userInfo);

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleCancel = () => {
    setIsFocused(false);
  };

  const handleComment = () => {
    // Implement your comment submission logic here
  };

  return (
    <>
      <div className="video-info__comment__top">
        <span className="video-info__comment__top__title">
          {resultData.data?.comments.length} Comments
        </span>
      </div>
      <div className="video-info__comment__input">
        <div className="video-info__comment__input__icon">
          <img src={userInfo?.photoURL} alt=""/>
        </div>
        <div className="video-info__comment__input__content">
          <FormControl fullWidth sx={{ m: 1 }} variant="standard">
            <Input
              sx={{
                color: "white",
                fontSize: "14px",
                fontWeight: "bold",
                textTransform: "capitalize",
                padding: "0px",
                borderBottom: "1px solid #AAAAAA",
              }}
              disableUnderline={true} // Correct usage of disableUnderline
              placeholder="Add a public comment..."
              onFocus={handleFocus}
            />
          </FormControl>
          {isFocused && (
            <div className="video-info__comment__input__content__button">
              <Button
                sx={{
                  color: "white",
                  fontSize: "14px",
                  fontWeight: "bold",
                  textTransform: "capitalize",
                  padding: "2px",
                }}
                variant="text"
                color="error"
                onClick={handleCancel}
              >
                Cancel
              </Button>
              <Button
                sx={{
                  color: "white",
                  fontSize: "14px",
                  fontWeight: "bold",
                  textTransform: "capitalize",
                  padding: "2px",
                }}
                variant="text"
                color="primary"
                onClick={handleComment}
              >
                Comment
              </Button>
            </div>
          )}
        </div>
      </div>
      <div className="video-info__comment__content">
        {resultData?.data?.comments?.map((comment, i) => (
          <AllComments key={i} comment={comment} />
        ))}
      </div>
    </>
  );
};

export default Comment;

