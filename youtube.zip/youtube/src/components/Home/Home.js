import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import DataCard from "../DataCard/DataCard";
import "./Home.scss";
import { setVideos } from "../../redux/reduxVideoData/videoData";

const Home = () => {
  const { data } = useSelector((state) => state.resultData);
  const {videos} = data;
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setVideos("", 50));
  }, []);

  return (
    <div className="home">
      <div className="data-cards">
        {videos.map((video, index) => (
          <DataCard key={index} data={video} />
        ))}
      </div>
    </div>
  );
};

export default Home;
