import { useDispatch, useSelector } from "react-redux";
import { setVideos } from "../../redux/reduxVideoData/videoData";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import MiniCard from "../MiniCard/MiniCard";
const VideoSidebar = () => {
  const resultData = useSelector((state) => state.resultData);
  const dispatch = useDispatch();
  const {videoId} = useParams();

  useEffect(() => {
    if (resultData?.data?.video?.snippet?.tags.length > 3)
      dispatch(
        setVideos(
          arrayToString(resultData?.data?.video?.snippet?.tags.slice(0, 3)),
          20
        )
      );
    else {
      dispatch(setVideos(resultData?.data?.video?.snippet?.title, 20));
    }
  }, [videoId]);

  const arrayToString = (array) => {
    if (array !== undefined) {
      return array.join(", ");
    }
  };

  return (
    <>
      {Array.isArray(resultData?.data?.video.get(videoId)?.snippet?.tags) &&
        resultData?.data?.video.get(videoId)?.snippet?.tags.length > 3 && (
          <ul className="video-sidebar__hashtags">
            <li
              className="video-sidebar__hashtags__tag"
              onClick={() =>
                dispatch(
                  setVideos(
                    arrayToString(
                      resultData?.data?.video.get(videoId)?.snippet?.tags.slice(0, 3)
                    ),
                    20
                  )
                )
              }
            >
              All
            </li>
            {resultData?.data?.video.get(videoId)?.snippet?.tags
              .slice(0, 3)
              .map((tag, i) => (
                <li
                  key={i}
                  className="video-sidebar__hashtags__tag"
                  onClick={() => dispatch(setVideos(tag, 20))}
                >
                  {tag}
                </li>
              ))}
          </ul>
        )}

      <div className="video-sidebar__suggestions">
        <div className="video-sidebar__suggestions_wrapper">
          {resultData?.data?.videos?.map((video, i) => (
            <MiniCard key={i} data={video} />
          ))}
        </div>
      </div>
    </>
  );
};

export default VideoSidebar;
