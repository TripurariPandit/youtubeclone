import { useDispatch } from "react-redux";
import { loginWithGoogle } from "../../components/LoginWithGoogle/LoginWithGoogle";
import googleIcon from "../../assets/images/google_icon.png";
import "./Login.scss";

const Login = () => {
  const dispatch = useDispatch();

  const handleSubmitWithGoogle = () => {
    dispatch(loginWithGoogle());
  };
  return (
    <div className="login">
      <div className="login-button" onClick={handleSubmitWithGoogle}>
        <div className="login-button__image">
          <img src={googleIcon} alt="google icon" />
        </div>
        <div className="login-button__text">
          <h5>
          Sign in with Google
          </h5>
        </div>
      </div>
    </div>
  );
};

export default Login;
