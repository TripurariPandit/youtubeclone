import { auth, provider } from "../../config";
import { signInWithPopup } from "firebase/auth";
import { authAction } from '../../redux/reducers/authReducer';

export const loginWithGoogle = () => {
  return async (dispatch) => {
    dispatch(authAction.loginRequest());

    try {
      const result = await signInWithPopup(auth, provider);
      dispatch(authAction.loginSuccess(result.user));
      window.location.reload();
    } catch (error) {
      dispatch(authAction.loginFailure(error.message));
    }
  };
};
