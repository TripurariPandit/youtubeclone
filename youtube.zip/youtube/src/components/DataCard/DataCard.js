import { useEffect, memo } from "react";
import "./DataCard.scss";
import numeral from "numeral";
import moment from "moment";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setChannel, setVideo } from "../../redux/reduxVideoData/videoData";

const DataCard = ({ data }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const channelInfo = useSelector((state) => state.resultData.data.channel);
  const videoInfo = useSelector((state)=> state.resultData.data.video);

  const {id} = data;
  const {videoId} = data?.id;
  const {url} = data?.snippet?.thumbnails?.high;
  
  useEffect(() => {
    dispatch(setChannel(data?.snippet?.channelId));
  }, [data?.snippet?.channelId, dispatch, id]);

  useEffect(() => {
    dispatch(setVideo(videoId))
  }, [videoId]);

  return (
    <div className={`data-card`}>
      <Link to={"/watch/" + videoId}>
        <div
          className={`data-card__media`}
          style={{
            backgroundImage: `url(${url})`,
          }}
        ></div>
      </Link>
      <div className="data-card__body">
        <div className="data-card__body-left">
          <img
            src={
              channelInfo[data?.snippet?.channelId]?.snippet?.thumbnails
                ?.default?.url
            }
            alt={channelInfo[data?.snippet?.channelId]?.snippet?.title}
          />
        </div>
        <div
          className="data-card__body-right"
          onClick={() => {
            navigate("/watch/" + videoId);
          }}
        >
          <p className="data-card__body-right__title">
            {data?.snippet.title.length < 50
              ? data?.snippet.title
              : data?.snippet.title.substring(0, 65) + "..."}
          </p>

          <div className="data-card__body-right__footer">
            <div className="data-card__body-right__footer__top">
              <p>{data?.snippet?.channelTitle}</p>
            </div>
            <div className="data-card__body-right__footer__bottom">
              <p>
                {numeral(videoInfo.get(data?.id?.videoId)?.statistics?.viewCount).format("0.a")} views
              </p>
              <p>{moment(data?.snippet?.publishedAt).fromNow()}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(DataCard);
