import "./App.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
// import Login from './components/Login/Login';
// import Collector from "./pages/Collector";
import HomePage from "./pages/HomePage/HomePage";
import VideoPage from "./pages/VideoPage/VideoPage";
import Layout from "./pages/Layout";

function App() {
  const router = createBrowserRouter([
    // {
    //   path: "/",
    //   // element: <Login />,
    //   element: (
    //     <Collector>
    //       <HomePage />
    //     </Collector>
    //   ),
    //   children: [
    //   {
    //     path: '/',
    //     element: <></>
    //   },
    //     {
    //       path: "/watch/:videoId",
    //       element: (
    //         <Collector>
    //           <VideoPage />
    //         </Collector>
    //       ),
    //     },
    //   ],
    // },

    {
      path: '/',
      element: <Layout />,
      children: [
        {
          path: '/',
          element: <HomePage />
        },
        {
          path: '/watch/:videoId',
          element: <VideoPage />
        }
      ]
    },
  ]);
  return <RouterProvider router={router} />;
}

export default App;
