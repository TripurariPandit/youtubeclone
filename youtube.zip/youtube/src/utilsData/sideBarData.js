import HomeIcon from "@mui/icons-material/Home";
import WhatshotOutlinedIcon from "@mui/icons-material/WhatshotOutlined";
import SubscriptionsOutlinedIcon from "@mui/icons-material/SubscriptionsOutlined";
import VideoLibraryOutlinedIcon from "@mui/icons-material/VideoLibraryOutlined";
import HistoryOutlinedIcon from "@mui/icons-material/HistoryOutlined";
import OndemandVideoOutlinedIcon from "@mui/icons-material/OndemandVideoOutlined";
import WatchLaterOutlinedIcon from "@mui/icons-material/WatchLaterOutlined";
import ThumbUpAltOutlinedIcon from "@mui/icons-material/ThumbUpAltOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import HelpOutlineOutlinedIcon from "@mui/icons-material/HelpOutlineOutlined";

export const sideBarData = {
  main: [
    {
      id: 1,
      icon: HomeIcon,
      text: "Home",
      link: "/",
    },
    {
      id: 2,
      icon: WhatshotOutlinedIcon,
      text: "Trending",
      link: "/",
    },
    {
      id: 3,
      icon: SubscriptionsOutlinedIcon,
      text: "Subscriptions",
      link: "/",
    },
  ],
  secondary: [
    {
      id: 1,
      icon: VideoLibraryOutlinedIcon,
      text: "Library",
      link: "/",
    },
    {
      id: 2,
      icon: HistoryOutlinedIcon,
      text: "History",
      link: "/",
    },
    {
      id: 3,
      icon: OndemandVideoOutlinedIcon,
      text: "Your videos",
      link: "/",
    },
    {
      id: 4,
      icon: WatchLaterOutlinedIcon,
      text: "Watch later",
      link: "/",
    },
    {
      id: 5,
      icon: ThumbUpAltOutlinedIcon,
      text: "Liked videos",
      link: "/",
    },
  ],
  setting: [
    {
      id: 1,
      icon: SettingsOutlinedIcon,
      text: "Settings",
      link: "/",
    },
    {
      id: 2,
      icon: FlagOutlinedIcon,
      text: "History Repository",
      link: "/",
    },
    {
      id: 3,
      icon: HelpOutlineOutlinedIcon,
      text: "Help",
      link: "/",
    },
  ]
};
