import axios from 'axios';

const YT_API = axios.create({
  baseURL: "https://youtube.googleapis.com/youtube/v3/",
  params: {
    key: "AIzaSyBrBvsz0dJIxe0x8Yj-jGARdzao6d-rFJU",
  },
}); 

export default YT_API;