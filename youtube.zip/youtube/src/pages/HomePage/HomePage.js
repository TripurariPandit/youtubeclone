import Home from '../../components/Home/Home'

const HomePage = () => <Home/>

export default HomePage
