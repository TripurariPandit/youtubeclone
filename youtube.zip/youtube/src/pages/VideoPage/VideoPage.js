import Video from '../../components/Video/Video'

const VideoPage = () => <Video/>

export default VideoPage