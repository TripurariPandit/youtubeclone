import Header from "../components/Header/Header";
import SideMenu from "../components/SideMenu/SideMenu";
import { Outlet } from "react-router-dom";
import { useSelector } from "react-redux";
const Layout = () => {
  const { toggle } = useSelector((state) => state.sideMenu);
  const sideMenuWidth = toggle ? "230px" : "70px";
  return (
    <>
      <Header />
      <Outlet />
      <SideMenu style={{ width: sideMenuWidth }} />
    </>
  );
};

export default Layout;
