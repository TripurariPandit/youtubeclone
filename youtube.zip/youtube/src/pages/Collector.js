import SideMenu from "../components/SideMenu/SideMenu"
import "./Collector.scss";
import Header from "../components/Header/Header";
import { useSelector, useDispatch } from "react-redux";
import { sideMenuAction } from "../redux/reducers/sideMenuReducer"

const Collector = ({ children }) => {
  const { toggle } = useSelector((state) => state.sideMenu);
  const sideMenuWidth = toggle ? "230px" : "70px";
  const dis = useDispatch();
  

  return (
    <div id="main-wrapper" style={{ position: "relative" }}>
      {toggle ? (
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "#000000b0",
            zIndex: 100,
          }}
          onClick={()=>dis(sideMenuAction.toggleSideMenu())}
        ></div>
      ) : (
        <></>
      )}
      <div id="header-wrapper">
        <Header />
      </div>
      <div id="side-menu" style={{ width: sideMenuWidth }}>
        <SideMenu />
      </div>
      <div id="main-contents">{children}</div>
    </div>
  );
};

export default Collector;
